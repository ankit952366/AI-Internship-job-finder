import streamlit as st
import re
from io import BytesIO
from pypdf import PdfReader

st.set_page_config(page_title="AI Internship & Job Agent", page_icon="🤖", layout="wide")
st.title("🤖 AI Internship & Job Finder")
st.caption("Upload a resume → analyze skills → discover matching opportunities")

st.markdown("""
This prototype analyzes a resume locally, identifies skills, and provides job-search links.
It does not submit applications automatically. Always review each listing and your application.
""")

SKILLS = ["python","java","c++","c","javascript","html","css","react","node.js","sql","mysql",
          "mongodb","machine learning","deep learning","artificial intelligence","data analysis",
          "pandas","numpy","tensorflow","pytorch","git","github","flask","django","streamlit",
          "communication","problem solving","web development","linux","cloud","aws","docker"]

def pdf_text(file):
    reader=PdfReader(BytesIO(file.read()))
    return "\n".join(page.extract_text() or "" for page in reader.pages)

def find_skills(text):
    lower=text.lower()
    return sorted({s.title() for s in SKILLS if s in lower})

def score_resume(text, skills):
    sections = ["education","project","experience","skill","certificate"]
    lower=text.lower()
    found=sum(1 for s in sections if s in lower)
    skill_score=min(40, len(skills)*4)
    section_score=found*10
    length_score=10 if len(text)>500 else 4
    return min(100, skill_score+section_score+length_score)

def job_search_url(query,site):
    from urllib.parse import quote_plus
    q=quote_plus(query)
    if site=="LinkedIn": return f"https://www.linkedin.com/jobs/search/?keywords={q}"
    if site=="Indeed": return f"https://in.indeed.com/jobs?q={q}"
    if site=="Naukri": return f"https://www.naukri.com/{q.replace('+','-')}-jobs"
    if site=="Google Jobs": return f"https://www.google.com/search?q={q}+jobs"
    return f"https://www.google.com/search?q={q}+internship"

with st.sidebar:
    st.header("Your preferences")
    role=st.text_input("Target role", "AI / Python Intern")
    location=st.text_input("Preferred location", "India / Remote")
    experience=st.selectbox("Experience", ["Student / Fresher","0-1 year","1+ years"])
    st.info("Tip: Use a text-based PDF resume for best results.")

resume=st.file_uploader("Upload your resume (PDF)", type=["pdf"])
if resume:
    try:
        text=pdf_text(resume)
        skills=find_skills(text)
        score=score_resume(text,skills)
        st.success("Resume parsed successfully.")
        c1,c2,c3=st.columns(3)
        c1.metric("Resume Score (prototype)",f"{score}/100")
        c2.metric("Skills found",len(skills))
        c3.metric("Text extracted",f"{len(text)} characters")
        st.subheader("Skills detected")
        if skills: st.write(", ".join(skills))
        else: st.warning("No known skills detected. Try a text-based PDF.")
        st.subheader("Skill-gap suggestions")
        target_skills=["Python","SQL","Git","Problem Solving","Machine Learning"]
        missing=[s for s in target_skills if s.lower() not in text.lower()]
        st.write("Consider adding/learning:",", ".join(missing) if missing else "Core skills appear in your resume.")
        st.subheader("Find matching opportunities")
        queries=[]
        if skills:
            top=skills[:5]
            queries=[f"{role} {', '.join(top)} {location}",f"{role} fresher {location}",f"{' '.join(top)} internship {location}"]
        else:
            queries=[f"{role} {location}",f"{role} fresher internship {location}"]
        platforms=["LinkedIn","Indeed","Naukri","Google Jobs"]
        for q in queries:
            st.markdown(f"**Search:** `{q}`")
            cols=st.columns(4)
            for col,platform in zip(cols,platforms):
                col.link_button(platform,job_search_url(q,platform),use_container_width=True)
        st.subheader("HR application email draft")
        draft=f"""Subject: Application for {role}

Dear Hiring Team,

I am a student/fresher interested in the {role} opportunity. My resume highlights skills including {', '.join(skills[:8]) if skills else 'relevant technical skills'}.

I would appreciate the opportunity to be considered. Please find my resume attached.

Thank you for your time and consideration.

Regards,
[Your Name]"""
        st.text_area("Edit and copy your email",draft,height=220)
        st.download_button("Download email draft",draft,"application_email.txt")
        with st.expander("View extracted resume text"):
            st.text(text[:12000])
    except Exception as e:
        st.error(f"Could not read this PDF: {e}")
else:
    st.markdown("### How it works")
    st.markdown("1. Upload your PDF resume.  2. Skills and resume sections are checked.  3. Search links are generated.  4. Review the job and apply on the official site.")
st.divider()
st.caption("Privacy: This prototype processes the uploaded PDF in the running app session. Do not upload sensitive information you don't want processed. This is a demo scoring system, not a guaranteed ATS score.")
