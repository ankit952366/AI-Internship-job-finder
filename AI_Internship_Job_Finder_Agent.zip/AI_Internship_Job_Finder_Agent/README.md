# AI Internship & Job Finder Agent (Prototype)

## Features
- PDF resume text extraction
- Skills detection from a predefined vocabulary
- Simple resume completeness score (not a real ATS score)
- Skill-gap suggestions
- Search links to LinkedIn, Indeed, Naukri and Google Jobs
- Editable HR email draft

## Run locally
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Deploy publicly (free option)
1. Create a GitHub repository and upload these files.
2. Open https://share.streamlit.io and sign in with GitHub.
3. Create app, select your repository, `streamlit_app.py`, and deploy.
4. Share the public `*.streamlit.app` link.

## Limitations
This prototype does not scrape job boards, guarantee that listings are current, or submit applications. It opens search results on job platforms. The resume score is a simple heuristic and should not be represented as an official ATS score.
